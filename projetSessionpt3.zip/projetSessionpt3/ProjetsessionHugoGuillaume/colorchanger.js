const divs = document.querySelectorAll("div"); 
divs.forEach((div , index) => {
div.style.backgroundColor = "#d9d9d9"
});
const buttons = document.querySelectorAll("button"); 
buttons.forEach((button , index) => {
button.style.backgroundColor = "red"
});